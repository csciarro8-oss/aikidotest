# Security Scanning Demo

Intentionally vulnerable code for testing GitHub's security features. **Never deploy.**

## Setup
1. Create a new **private** repo and push these files to `main`.
2. Repo **Settings → Advanced Security** (or **Code security**): enable
   - Dependency graph + Dependabot alerts + Dependabot security updates
   - Secret scanning (+ push protection)
   - Code scanning (the included `codeql.yml` workflow runs it)
3. Wait a few minutes, then check the **Security** tab.

## What you should see
| Feature | Where | Expected findings |
|---|---|---|
| CodeQL | `app.py` | SQL/command injection, XSS, path traversal, unsafe deserialization, open redirect, weak hash, debug mode |
| Dependabot | `requirements.txt` | Alerts for flask, requests, pyyaml, jinja2, urllib3, plus auto-PRs |
| Secret scanning | `config.py` | AWS key pattern, possibly blocked by push protection |

## Things to try next
- Open a PR that adds a new vulnerable line and watch code scanning annotate the diff.
- Fix one finding and confirm the alert auto-closes.
- Dismiss an alert and see how dismissal reasons are recorded.

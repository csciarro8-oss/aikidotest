# FAKE credentials for testing secret scanning.
# The AWS value below is Amazon's documented example key, not a real credential.
# Note: GitHub push protection may block pushes containing well-known token formats.
# That is the feature working; you can bypass it in the prompt for this demo.

AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

DB_PASSWORD = "SuperSecret123!"  # hardcoded password (CodeQL: py/hardcoded-credentials)

"""
INTENTIONALLY VULNERABLE demo app for testing GitHub code scanning (CodeQL).
Do NOT deploy this anywhere. Use a private/throwaway repo.
"""
import hashlib
import os
import pickle
import sqlite3
import subprocess

import yaml
from flask import Flask, request, redirect

app = Flask(__name__)


def get_db():
    return sqlite3.connect("demo.db")


# 1. SQL injection (py/sql-injection)
@app.route("/user")
def get_user():
    username = request.args.get("name", "")
    query = "SELECT * FROM users WHERE name = '" + username + "'"
    return str(get_db().execute(query).fetchall())


# 2. Command injection (py/command-line-injection)
@app.route("/ping")
def ping():
    host = request.args.get("host", "")
    return subprocess.check_output("ping -c 1 " + host, shell=True)


# 3. Reflected XSS (py/reflective-xss)
@app.route("/hello")
def hello():
    name = request.args.get("name", "")
    return "<h1>Hello " + name + "</h1>"


# 4. Path traversal (py/path-injection)
@app.route("/read")
def read_file():
    filename = request.args.get("file", "")
    with open(os.path.join("/var/data", filename)) as f:
        return f.read()


# 5. Unsafe deserialization (py/unsafe-deserialization)
@app.route("/load", methods=["POST"])
def load():
    return str(pickle.loads(request.data))


# 6. Unsafe YAML load (py/unsafe-deserialization)
@app.route("/yaml", methods=["POST"])
def load_yaml():
    return str(yaml.load(request.data, Loader=yaml.Loader))


# 7. Open redirect (py/url-redirection)
@app.route("/go")
def go():
    return redirect(request.args.get("url", "/"))


# 8. Weak hashing for passwords (py/weak-sensitive-data-hashing)
def hash_password(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()


if __name__ == "__main__":
    # 9. Flask debug mode enabled (py/flask-debug)
    app.run(host="0.0.0.0", debug=True)
